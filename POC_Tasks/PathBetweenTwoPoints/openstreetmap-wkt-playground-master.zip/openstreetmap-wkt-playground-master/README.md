# OpenstreetMap WKT Playground
Plot [WKT](https://en.wikipedia.org/wiki/Well-known_text) shapes on [OpenSteetMap](https://www.openstreetmap.org)    
    
See it working https://clydedacruz.github.io/openstreetmap-wkt-playground  

![playground-demo](https://raw.githubusercontent.com/clydedacruz/openstreetmap-wkt-playground/master/wkt-playgound.gif)