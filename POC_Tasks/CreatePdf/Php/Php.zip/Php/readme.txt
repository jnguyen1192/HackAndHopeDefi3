1) Put this directory on the www
2) Launch the index.html on your server
3) Sign and click on submit to create the pdf
4) Find the pdf called test_php_image.pdf in the index.html same directory

Happy coding !